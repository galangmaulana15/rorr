#include <stdio.h>
#include <conio.h>
#include <string.h>

char nomor[100], inp;
int idx = 0;

void kartu()
{
    printf("Input Nomor HP (Minimal 10 Angka, Maksimal 15 Angka, Berawalan 08 atau 62): ");

    while (1)
    {
        // inputan getch berfungsi untuk mengisi ketikan tapi tidak tampil langsung ke cmd
        inp = getch();

        // jika inputan memenuhi kondisi mengharuskan awalan 08 atau 62 (inputan harus dibawah 15) diprint %c dulu
        if (idx == 0 && inp == '0' || idx == 0 && inp == '6' || nomor[0] == '0' && idx == 1 && inp == '8' ||
        nomor[0] == '6' && idx == 1 && inp == '2' || idx > 1 && idx < 15 && inp >= '0' && inp <= '9' && inp != ' ')
        {
            printf("%c", inp);
            nomor[idx++] = inp;
        }

        // jika salah di hapus menggunakan \b
        else if (inp == 8 && idx > 0)
        {
            printf("\b \b");
            nomor[--idx] = '\0';
        }

        // \r disini dimaksudkan untuk jika menekan enter
        else if (inp == '\r')
        {
            // jika inputan >= 10, enter berfungsi dan keluar dari perulangan menggunakan break
            if (idx >= 10)
            {
                nomor[idx] = '\0';
                idx = 0;
                break;

            }
                /* jika inputan alias indeksnya <= 10 tidak, codingan berbunyi
                dan mengulang untuk mengharuskan input kembali*/
            else
            {
                printf("\a");
            }
        }
    }

    /*while disini dimaksudkan untuk inputan 1 1 karakter dan jika kondisi terpenuhi
    akan mengulang kembali setelah diprint %c atau dihapus dengan \b*/

    char nom[20]; // Array untuk tampungan

    // JIKA Awalan 62 diubah menjadi 08 untuk menyamakan kondisi
    if (nomor[0] == '6' && nomor[1] == '2') {
        nom[0] = '0'; // Mengubah awalan 62 menjadi 0

        // Memindahkan sisa karakter setelah awalan 62 atau memundurkan indeks
        for (int i = 1; i < strlen(nomor) - 1; i++) {
            nom[i] = nomor[i + 1];
        }
        // Menambahkan terminator string
        nom[strlen(nomor) - 2] = '\0';
    }
    // jika tetap awalan 08 dipindahkan juga kearray baru tanpa memundurkan indeks
    else{
        strcpy(nom,nomor);
    }

    // Identifikasi jenis kartu berdasarkan indeks ketiga dan keempat
    printf("\nKartu Anda ");
    if (nom[2] == '5' && (nom[3] == '3' || nom[3] == '2' || nom[3] == '1')) {
        printf("Telkomsel");
    } else if (nom[2] == '2' && nom[3] == '1') {
        printf("Axis");
    } else {
        printf("Tidak diketahui");
    }
    
}

void main(){
    kartu();
}