#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include "tampilan.c"
// #include "mainkanvlds.c"
// #include "Crud.c"
// #include "all fungsi.c"

void main(){
    tampilan_pilih(); 
}

