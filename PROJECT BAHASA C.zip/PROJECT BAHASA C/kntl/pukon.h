#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#define sys system("cls");
#define MAX 100

#define besar inp >= 'A' && inp <= 'Z'
#define kecil inp >= 'a' && inp <= 'z'
#define angka inp >= '0' && inp <= '9'

////////////////////////////////////////////////
    char *vemail(char tamp[100])
{
    char inp;
    char bag[99] = {};
    int idx = 0;
    int a = strlen(tamp); 

    if (a != 0)
    {
        idx = a;
    }

    while (1)
    {
        inp = getch();

        if (idx < 18 && (tamp[idx - 10] != '@') && (kecil || besar || angka || inp == '@') || (tamp[idx - 6] == '@' && inp == '.'))
        {
            printf("%c", inp);
            tamp[idx++] = inp;
        }
        else if (inp == 8 && idx > 0)
        {
            printf("\b \b");
            tamp[--idx] = '\0';
        }
        else if (inp == 13 && strstr(tamp, "@gmail.com") != 0)
        {
            tamp[idx] = '\0';
            idx = 0;
            break;
        }
        else if(inp == 27){
            system("cls");
            tampilan_pilih();
        }
        else
        {
            printf("\a");
        }
    }
    return tamp;
}

    char *vusername(char tamp[100])
{
    char inp;
    int idx = 0;
    int a = strlen(tamp);
    if (a != 0)
    {
        idx = a;
    }

    while (1)
    {
        inp = getch();
        if (idx < 10 && (kecil || besar || angka || inp == '_'))
        {
            printf("%c", inp);
            tamp[idx++] = inp;
        }
        else if (inp == 8 && idx > 0)
        {
            printf("\b \b");
            tamp[--idx] = '\0';
        }
        else if (inp == 13)
        {
            tamp[idx] = '\0';
            idx = 0;
            break;
        }
        else if (inp == 27){
            system("cls");
            tampilan_pilih();
            
        }
        else
        {
            printf("\a");
        }
    }
    return tamp;
}

    char *vnama(char tamp[100]){
    int idx = 0;
    char inp;
    int a = strlen(tamp);
    while(inp = getch()){
        if((idx == 0 ||tamp[idx-1]== ' ' ) && inp >= 'A' && inp <= 'Z'||idx >= 1 && idx <= 15 && inp >= 'a' && inp <= 'z'&&tamp [idx - 1]!= ' '
        ||tamp[idx-1]!= 'a' && tamp[idx-1]!='z'&& inp == ' '&&tamp[idx-1]!=' '){
            printf("%c", inp);
           tamp[idx]= inp;
            idx++;
        }
        else if(inp == 8 && idx > 0){
            printf("\b \b");
           tamp[idx]= '\0';
            idx--;
        }
        else if(inp == 13 && idx >= 10){
           tamp[idx] = '\0';
            break;
        }else if(inp == 27){
            system("cls");
            tampilan_pilih();
            
        }
        else{
            printf("\a");
            
        }
    }
}

    void *vpass(char ps[100]){

    char inp;
    // char bag[99] = {};
    int index = 0;
    while ((inp = getch()) != 13 || index < 5)
    {
        if (index <= 13 && (inp >= 'a' && inp <= 'z'||inp >= 'A' && inp <= 'Z'
        ||inp >= '0' && inp <= '9'))
        {
            printf("*",inp);
            ps[index] = inp;
            index++;
        }
        else if (inp == 8 && index != 0)
        {
            printf("\b \b");
            index -= 1;
            ps[index] = '\0';
        }
        else if(inp == 27){
            system("cls");
            tampilan_pilih();
        }
        else{
            printf("\a");
        }
        
    }
}

    char *vnohp(char tamp[100])
{
    char inp;
    int idx = 0;
    int a = strlen(tamp);
    if (a != 0)
    {
        idx = a;
    }

    while (1)
    {
        inp = getch();
        if (idx == 0 && inp == '0' || idx == 0 && inp == '6' || tamp[0] == '0' && idx == 1 && inp == '8' ||
            tamp[0] == '6' && idx == 1 && inp == '2' || idx > 1 && idx < 15 && angka && inp != ' ')
        {
            printf("%c", inp);
            tamp[idx++] = inp;
        }
        else if (inp == 8 && idx > 0)
        {
            printf("\b \b");
            tamp[--idx] = '\0';
        }
        else if (inp == '\r' && idx >= 11)
        {
            tamp[idx] = '\0';
            idx = 0;
            break;
        }
        else if (inp == 27)
        {
            system("cls");
            tampilan_pilih();
        }
        else
        {
            printf("\a");
        }
    }
}
///////////////////////////////////////////////
void koordinat(int x, int y)
{
    COORD koordinat;
    koordinat.X = x;
    koordinat.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), koordinat);
}

#include "show.c"
#include "allpuki.c"