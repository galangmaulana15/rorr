#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>

#define sys system("cls");
#define MAX 100

void login1();
void admin();

char email[20], namalengkap[50], username[20],password[10], nomor[10];
void daftar1()
{
    sys 
    FILE*data_semua = fopen ("data.txt","a");
    // bingkai_all(28, 80, 27, 0);
    bingkai_all(8, 75, 27, 0);
    bingkai_all(8, 75, 27, 7);
    bingkai_all(8, 75, 27, 10);
    bingkai_all(8, 75, 27, 13);
    bingkai_all(8, 75, 27, 16);
    bingkai_all(8, 75, 27, 19);
    bingkai_all(8, 75, 27, 22);
    tD();
    koordinat(1,33); printf("TEKAN ESC UNTUK KEMBALI KE MENU");

    koordinat(40, 9);
    printf("Masukkan Nama Lengkap :");
    koordinat(40, 12);
    printf("Masukkan Nomor        :");
    koordinat(40, 15);
    printf("Masukkan User Name    :");
    koordinat(40, 18);
    printf("Masukkan email        : ");
    koordinat(40, 21);
    printf("Masukkan password     : ");
   

    koordinat(64, 9);
    vnama(namalengkap);
    koordinat(64, 12);
    vnohp(nomor);
    koordinat(64,15);
    vusername(username);
    koordinat(64, 18);
    vemail(email);
    koordinat(64, 21);
    vpass(password);

    fprintf(data_semua,"%s/%s/%s/%s/%s\n",namalengkap,nomor,username,email,password);
    fclose(data_semua);

    login1();
}

void login1()
{
    int i = 0;
    char user[10], pw[20];
    do
    {
    sys
    bingkai_all(20, 80, 27, -1);
    bingkai_all(20, 80, 27, 7);
    tL();
    koordinat(1,33); printf("TEKAN ESC UNTUK KEMBALI KE MENU");

    koordinat(55, 11);
    printf("Masukkan user anda : ");
    vusername(user);
    koordinat(55, 12);
    printf("Masukkan Password anda : ");
    vpass(pw);
    FILE*baca = fopen("data.txt","r");
    while (fscanf(baca,"%[^/]/%[^/]/%[^/]/%[^/]/%[^\n]",namalengkap,nomor,username,email,password) != EOF);
    {
        if(strcmp(user,username)==0 && strcmp(pw,password)==0)
        {
            koordinat(55,14); printf("login berhasil");
            getchar();
            sys
            tampilan_pilih();
            break;
            
        }
    }          
    fclose(baca);
    if (i == 3)
    {
        koordinat(50,12); printf("akun anda terkunci untuk sementara");
        return;
    }else
    {
        koordinat(50,13); printf("login gagal,harap coba lagii !");
    }
    i++;

    } while (i < 3);
}

void login_admin(){
    char login[100],pw[20];
    sys
    bingkai_all(28, 80, 27, 0);
    koordinat(1,33); printf("TEKAN ESC UNTUK KEMBALI KE MENU");
    koordinat(53, 5); printf("LOGIN ADMIN : ");
    scanf("%s", &login);
    koordinat(53, 6); printf("Password : ");
    scanf("%s", &pw);
    printf("login berhasil");

    admin();

}

void admin(){
    sys
    bingkai_all(20,40,8,0);
    printf("TAMBAHKAN LAGU ");
    printf("LIST USER");
    printf("DAFTAR LAGU");
    printf("HAPUS LAGU");
}

