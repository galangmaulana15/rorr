#include "show.c"

void main(){
    tampilan_pilih();
}