#include "all fungsi.c"

void pesawat();
void bingkai();
void sportify();
void logo_daftar();
void logo_admin();
void logo_login();
void logo_keluar();

int cek = 0,halaman;


// a = 137
// b = 34

// void  galang_spasi(const char *text)
// {
//     HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
//     CONSOLE_SCREEN_BUFFER_INFO csbi;

//     // Mendapatkan informasi layar terminal
//     if (GetConsoleScreenBufferInfo(hConsole, &csbi))
//     {
//         int width = csbi.srWindow.Right - csbi.srWindow.Left + 1; // Lebar layar terminal
//         int text_length = strlen(text);                           // Panjang teks
//         int padding = (width - text_length) / 2;                  // Spasi kiri untuk rata tengah

//         // Cetak spasi untuk rata tengah
//         for (int x = 0; x < padding; x++)
//         {
//             printf(" ");
//         }
//         printf("%s", text); // Cetak teks
//     }
//     else
//     {
//         // Jika gagal mendapatkan lebar layar, cetak teks biasa
//         printf("%s", text);
//     }
// }

void koordinat(int x, int y)
{
    COORD koordinat;
    koordinat.X = x;
    koordinat.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), koordinat);
}

void pesawat()
{
    for (int i = 0; i < 70; i++)
    {
        koordinat(53, 5); //
        printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", 201, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 187);
        koordinat(53, 6);
        printf("%c   HARAP TUNGGU SEBENTAR !   %c\n", 186, 186);
        koordinat(53, 7);
        printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n\n", 200, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 188);

        koordinat(0 + i, 10);
        printf("        ______                                       \n");
        koordinat(0 + i, 11);
        printf("    _\\ _~-\\___                                     \n");
        koordinat(0 + i, 12);
        printf("   ====(____AA____D                                  \n");
        koordinat(0 + i, 13);
        printf("        \\_____\\___________________,-~~~~~~~`-.._   \n");
        koordinat(0 + i, 14);
        printf("        /     o O o o o o O O o o o o o o O o  |\\_  \n");
        koordinat(0 + i, 15);
        printf("        `~-.__        ___..----..                  ) \n");
        koordinat(0 + i, 16);
        printf("              `---~~\\___________/------------`````  \n");
        koordinat(0 + i, 17);
        printf("                 ===(_________D\n");
        Sleep(10);
        system("cls");
    }
}

void red()
{
    printf("\033[0;34;47m");
}

void pink(){
    printf("\033[0;45;47m");
}

void reset()
{
    printf("\033[0;35;47m");
}
void sportify()
{
    //  Sleep(100);
   char q=222,  //blok setengah ▐ q
      r=223,  // kotak atas   ▀ r
      s=219,  //blok          %c s
      t=187,  //kanan atas    %c t
      u=188,  //kanan bawah   %c u
      v=186,  //lurus atas    %c v
      x=205,  //lurus garis   %c x
      w=201,  //kiri atas     %c w
      y=200,  //kiri bawah    %c y
      z=220;  //kotak bawah   ▄ z

    system("COLOR 75");
    koordinat(42, 2);
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c  %c%c%c%c%c%c%c %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c   %c%c%c", s, s, s, s, s, s, s, t, s, s, s, s, s, s, t, s, s, s, s, s, s, t, s, s, s, s, s, s, s, s, t, s, s, t, s, s, s, s, s, s, s, t, s, s, t, s, s, t);
    koordinat(42, 3);
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c %c%c%c%c", s, s, w, x, x, x, x, u, s, s, w, x, x, s, s, t, s, s, w, x, x, x, s, s, t, y, x, x, s, s, w, x, x, u, s, s, v, s, s, w, x, x, x, x, u, y, s, s, t, s, s, w, u);
    koordinat(42, 4);
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c   %c%c%c   %c%c%c   %c%c%c%c%c%c%c%c%c   %c%c%c%c%c%c%c ", s, s, s, s, s, s, s, t, s, s, s, s, s, s, w, u, s, s, v, s, s, v, s, s, v, s, s, v, s, s, s, s, s, t, y, s, s, s, s, w, u);
    koordinat(42, 5);
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c %c%c%c   %c%c%c   %c%c%c   %c%c %c%c%c%c%c%c    %c%c%c%c%c  ", y, x, x, x, x, s, s, v, s, s, w, x, x, x, u, s, s, v, s, s, v, s, s, v, s, s, s, s, w, x, x, u, y, s, s, w, u);
    koordinat(42, 6);
    printf("%c%c%c%c%c%c%c%c%c%c%c     %c%c%c%c%c%c%c%c%c   %c%c%c   %c%c%c%c%c%c        %c%c%c   ", s, s, s, s, s, s, s, v, s, s, v, y, s, s, s, s, s, s, w, u, s, s, v, s, s, v, s, s, v, s, s, v);
    koordinat(42, 7);
    printf("%c%c%c%c%c%c%c%c%c%c%c      %c%c%c%c%c%c%c    %c%c%c   %c%c%c%c%c%c        %c%c%c", y, x, x, x, x, x, x, u, y, x, u, y, x, x, x, x, x, u, y, x, u, y, x, u, y, x, u, y, x, u);
}

/// 3,19 ///
void logo_daftar()
{
    //    Sleep(150);
 char q=222,  //blok setengah ▐ q
      r=223,  // kotak atas   ▀ r
      s=219,  //blok          %c s
      t=187,  //kanan atas    %c t
      u=188,  //kanan bawah   %c u
      v=186,  //lurus atas    %c v
      x=205,  //lurus garis   %c x
      w=201,  //kiri atas     %c w
      y=200,  //kiri bawah    %c y
      z=220;  //kotak bawah   ▄ z


koordinat(3,19);    printf("%c%c%c%c%c%c%c  %c%c%c%c%c%c %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c %c%c%c%c%c%c %c%c%c%c%c%c%c", s, s, s, s, s, s, t, s, s, s, s, s, t, s, s, s, s, s, s, s, t, s, s, s, s, s, s, s, s, t, s, s, s, s, s, t, s, s, s, s, s, s, t);
koordinat(3,20);    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, w, x, x, s, s, t, s, s, w, x, x, s, s, t, s, s, w, x, x, x, x, u, y, x, x, s, s, w, x, x, u, s, s, w, x, x, s, s, t, s, s, w, x, x, s, s, t);
koordinat(3,21);    printf("%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c     %c%c%c   %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, v, s, s, v, s, s, s, s, s, s, s, v, s, s, s, s, s, t, s, s, v, s, s, s, s, s, s, s, v, s, s, s, s, s, s, w, u);
koordinat(3,22);    printf("%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c     %c%c%c   %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, v, s, s, v, s, s, w, x, x, s, s, v, s, s, w, x, x, u, s, s, v, s, s, w, x, x, s, s, v, s, s, w, x, x, s, s, t);
koordinat(3,23);    printf("%c%c%c%c%c%c%c%c%c%c%c  %c%c%c%c%c%c        %c%c%c   %c%c%c  %c%c%c%c%c%c  %c%c%c", s, s, s, s, s, s, w, u, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v);
koordinat(3,24);    printf("%c%c%c%c%c%c%c %c%c%c  %c%c%c%c%c%c        %c%c%c   %c%c%c  %c%c%c%c%c%c  %c%c%c", y, x, x, x, x, x, u, y, x, u, y, x, u, y, x, u, y, x, u, y, x, u, y, x, u, y, x, u, y, x, u);

}

/////48,11 //////
void logo_admin()
{
    // Sleep(200);
   char q=222,  //blok setengah ▐ q
      r=223,  // kotak atas   ▀ r
      s=219,  //blok          s, s
      t=187,  //kanan atas    t, t
      u=188,  //kanan bawah   u, u
      v=186,  //lurus atas    v, v
      x=205,  //lurus garis   x, x
      w=201,  //kiri atas     w, w
      y=200,  //kiri bawah    y, y
      z=220;  //kotak bawah   ▄ z

koordinat(48,11);printf(" %c%c%c%c%c%c %c%c%c%c%c%c%c %c%c%c%c   %c%c%c%c%c%c%c%c%c%c%c   %c%c%c",s,s,s,s,s,t, s,s,s,s,s,s,t, s,s,s,t,   s,s,s,t,s,s,t,s,s,s,t,   s,s,t);
koordinat(48,12);printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c %c%c%c%c%c%c%c%c%c%c%c%c%c  %c%c%c",s,s,w,x,x,s,s,t,s,s,w,x,x,s,s,t,s,s,s,s,t, s,s,s,s,v,s,s,v,s,s,s,s,t,  s,s,v);
koordinat(48,13);printf("%c%c%c%c%c%c%c%c%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c %c%c%c",s,s,s,s,s,s,s,v,s,s,v,  s,s,v,s,s,w,s,s,s,s,w,s,s,v,s,s,v,s,s,w,s,s,t, s,s,v);
koordinat(48,14);printf("%c%c%c%c%c%c%c%c%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c %c%c%c%c%c%c",s,s,s,s,s,s,s,v,s,s,v,  s,s,v,s,s,w,s,s,s,s,w,s,s,v,s,s,v,s,s,w,s,s,t, s,s,v);
koordinat(48,15);printf("%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c %c%c%c %c%c%c%c%c%c%c%c%c %c%c%c%c%c%c",s,s,v,  s,s,v,s,s,s,s,s,s,w,u,s,s,v, y,x,u, s,s,v,s,s,v,s,s,v, y,s,s,s,s,v);
koordinat(48,16);printf("%c%c%c  %c%c%c%c%c%c%c%c%c%c %c%c%c     %c%c%c%c%c%c%c%c%c  %c%c%c%c%c",y,x,u,  y,x,u,y,x,x,x,x,x,u, y,x,u,     y,x,u,y,x,u,y,x,u,  y,x,x,x,u);
// login_admin();

}
void logo_login()
{
    // Sleep(250);
    char q = 222, // blok setengah ▐ q
        r = 223,  // kotak atas   ▀ r
        s = 219,  // blok          s, s
        t = 187,  // kanan atas    t, t
        u = 188,  // kanan bawah   u, u
        v = 186,  // lurus atas    v, v
        x = 205,  // lurus garis   x, x
        w = 201,  // kiri atas     w, w
        y = 200,  // kiri bawah    y, y
        z = 220;  // kotak bawah   ▄ z

    koordinat(89, 19);
    printf("%c%c%c      %c%c%c%c%c%c%c  %c%c%c%c%c%c%c     %c%c%c%c%c%c%c   %c%c%c", s, s, t, s, s, s, s, s, s, t, s, s, s, s, s, s, t, s, s, t, s, s, s, t, s, s, t);
    koordinat(89, 20);
    printf("%c%c%c     %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c     %c%c%c%c%c%c%c%c  %c%c%c", s, s, v, s, s, w, x, x, x, s, s, t, s, s, w, x, x, x, x, u, s, s, v, s, s, s, s, t, s, s, v);
    koordinat(89, 21);
    printf("%c%c%c     %c%c%c   %c%c%c%c%c%c  %c%c%c%c    %c%c%c%c%c%c%c%c%c %c%c%c", s, s, v, s, s, v, s, s, v, s, s, v, s, s, s, t, s, s, v, s, s, w, s, s, t, s, s, v);
    koordinat(89, 22);
    printf("%c%c%c     %c%c%c   %c%c%c%c%c%c   %c%c%c    %c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, y, s, s, t, s, s, v);
    koordinat(89, 23);
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c    %c%c%c%c%c%c %c%c%c%c%c%c", s, s, s, s, s, s, s, t, y, s, s, s, s, s, s, w, u, y, s, s, s, s, s, s, w, u, s, s, v, s, s, v, y, s, s, s, s, v);
    koordinat(89, 24);
    printf("%c%c%c%c%c%c%c%c %c%c%c%c%c%c%c  %c%c%c%c%c%c%c     %c%c%c%c%c%c  %c%c%c%c%c", y, x, x, x, x, x, x, u, y, x, x, x, x, x, u, y, x, x, x, x, x, u, y, x, u, y, x, u, y, x, x, x, u);
}

void logo_keluar()
{
    // Sleep(300);
    char q=222,  //blok setengah ▐ q
      r=223,  // kotak atas   ▀ r
      s=219,  //blok          %c s
      t=187,  //kanan atas    %c t
      u=188,  //kanan bawah   %c u
      v=186,  //lurus atas    %c v
      x=205,  //lurus garis   %c x
      w=201,  //kiri atas     %c w
      y=200,  //kiri bawah    %c y
      z=220;  //kotak bawah   ▄ z


    koordinat(42, 27);
    printf("%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c     %c%c%c   %c%c%c %c%c%c%c%c%c %c%c%c%c%c%c%c ", s, s, t, s, s, t, s, s, s, s, s, s, s, t, s, s, t, s, s, t, s, s, t, s, s, s, s, s, t, s, s, s, s, s, s, t);
    koordinat(42, 28);
    printf("%c%c%c %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c     %c%c%c   %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, v, s, s, w, u, s, s, w, x, x, x, x, u, s, s, v, s, s, v, s, s, v, s, s, w, x, x, s, s, t, s, s, w, x, x, s, s, t);
    koordinat(42, 29);
    printf("%c%c%c%c%c%c%c %c%c%c%c%c%c  %c%c%c     %c%c%c   %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, s, s, s, w, u, s, s, s, s, s, t, s, s, v, s, s, v, s, s, v, s, s, s, s, s, s, s, v, s, s, s, s, s, s, w, u);
    koordinat(42, 30);
    printf("%c%c%c%c%c%c%c %c%c%c%c%c%c  %c%c%c     %c%c%c   %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, w, x, s, s, t, s, s, w, x, x, u, s, s, v, s, s, v, s, s, v, s, s, w, x, x, s, s, v, s, s, w, x, x, s, s, t);
    koordinat(42, 31);
    printf("%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c", s, s, v, s, s, t, s, s, s, s, s, s, s, t, s, s, s, s, s, s, s, t, y, s, s, s, s, s, s, w, u, s, s, v, s, s, v, s, s, v, s, s, v);
    koordinat(42, 32);
    printf("%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c %c%c%c%c%c%c%c %c%c%c  %c%c%c%c%c%c  %c%c%c", y, x, u, y, x, u, y, x, x, x, x, x, x, u, y, x, x, x, x, x, x, u, y, x, x, x, x, x, u, y, x, u, y, x, u, y, x, u, y, x, u);
}

void tD(){
    //    Sleep(150);
 char q=222,  //blok setengah ▐ q
      r=223,  // kotak atas   ▀ r
      s=219,  //blok          %c s
      t=187,  //kanan atas    %c t
      u=188,  //kanan bawah   %c u
      v=186,  //lurus atas    %c v
      x=205,  //lurus garis   %c x
      w=201,  //kiri atas     %c w
      y=200,  //kiri bawah    %c y
      z=220;  //kotak bawah   ▄ z


koordinat(40,2);   printf("%c%c%c%c%c%c%c  %c%c%c%c%c%c %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c %c%c%c%c%c%c %c%c%c%c%c%c%c", s, s, s, s, s, s, t, s, s, s, s, s, t, s, s, s, s, s, s, s, t, s, s, s, s, s, s, s, s, t, s, s, s, s, s, t, s, s, s, s, s, s, t);
koordinat(40,3);    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, w, x, x, s, s, t, s, s, w, x, x, s, s, t, s, s, w, x, x, x, x, u, y, x, x, s, s, w, x, x, u, s, s, w, x, x, s, s, t, s, s, w, x, x, s, s, t);
koordinat(40,4);    printf("%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c     %c%c%c   %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, v, s, s, v, s, s, s, s, s, s, s, v, s, s, s, s, s, t, s, s, v, s, s, s, s, s, s, s, v, s, s, s, s, s, s, w, u);
koordinat(40,5);    printf("%c%c%c  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c     %c%c%c   %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, v, s, s, v, s, s, w, x, x, s, s, v, s, s, w, x, x, u, s, s, v, s, s, w, x, x, s, s, v, s, s, w, x, x, s, s, t);
koordinat(40,6);    printf("%c%c%c%c%c%c%c%c%c%c%c  %c%c%c%c%c%c        %c%c%c   %c%c%c  %c%c%c%c%c%c  %c%c%c", s, s, s, s, s, s, w, u, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v);
koordinat(40,7);    printf("%c%c%c%c%c%c%c %c%c%c  %c%c%c%c%c%c        %c%c%c   %c%c%c  %c%c%c%c%c%c  %c%c%c", y, x, x, x, x, x, u, y, x, u, y, x, u, y, x, u, y, x, u, y, x, u, y, x, u, y, x, u, y, x, u);

}

void tL()
{
    // Sleep(250);
    char q = 222, // blok setengah ▐ q
        r = 223,  // kotak atas   ▀ r
        s = 219,  // blok          s, s
        t = 187,  // kanan atas    t, t
        u = 188,  // kanan bawah   u, u
        v = 186,  // lurus atas    v, v
        x = 205,  // lurus garis   x, x
        w = 201,  // kiri atas     w, w
        y = 200,  // kiri bawah    y, y
        z = 220;  // kotak bawah   ▄ z

    koordinat(45, 1);
    printf("%c%c%c      %c%c%c%c%c%c%c  %c%c%c%c%c%c%c     %c%c%c%c%c%c%c   %c%c%c", s, s, t, s, s, s, s, s, s, t, s, s, s, s, s, s, t, s, s, t, s, s, s, t, s, s, t);
    koordinat(45, 2);
    printf("%c%c%c     %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c     %c%c%c%c%c%c%c%c  %c%c%c", s, s, v, s, s, w, x, x, x, s, s, t, s, s, w, x, x, x, x, u, s, s, v, s, s, s, s, t, s, s, v);
    koordinat(45, 3);
    printf("%c%c%c     %c%c%c   %c%c%c%c%c%c  %c%c%c%c    %c%c%c%c%c%c%c%c%c %c%c%c", s, s, v, s, s, v, s, s, v, s, s, v, s, s, s, t, s, s, v, s, s, w, s, s, t, s, s, v);
    koordinat(45, 4);
    printf("%c%c%c     %c%c%c   %c%c%c%c%c%c   %c%c%c    %c%c%c%c%c%c%c%c%c%c%c%c%c", s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, s, s, v, y, s, s, t, s, s, v);
    koordinat(45, 5);
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c    %c%c%c%c%c%c %c%c%c%c%c%c", s, s, s, s, s, s, s, t, y, s, s, s, s, s, s, w, u, y, s, s, s, s, s, s, w, u, s, s, v, s, s, v, y, s, s, s, s, v);
    koordinat(45, 6);
    printf("%c%c%c%c%c%c%c%c %c%c%c%c%c%c%c  %c%c%c%c%c%c%c     %c%c%c%c%c%c  %c%c%c%c%c", y, x, x, x, x, x, x, u, y, x, x, x, x, x, u, y, x, x, x, x, x, u, y, x, u, y, x, u, y, x, x, x, u);
}

void tampilan1()
{
    sportify();
    red();
    logo_login();
    reset();
    logo_admin();
    logo_daftar();
    logo_keluar();
}
void tampilan2()
{
    sportify();
    logo_login();
    red();
    logo_admin();
    reset();
    logo_daftar();
    logo_keluar();
}
void tampilan3()
{
    sportify();
    logo_login();
    logo_admin();
    red();
    logo_daftar();
    reset();
    logo_keluar();
}
void tampilan4()
{
    sportify();
    logo_login();
    logo_admin();
    logo_daftar();
    red();
    logo_keluar();
    reset();
}


// bingkai awall 
void bingkai()
{
    int a = 135, b = 34;
    char s = 219;
    for (int x = 0; x < b; x++)
    {
        koordinat(0, 0 + x);
        for (int j = 0; j < a; j++)
        {

            if (x == 0 || x == b - 1 || j == 0 || j == a - 1)
            {
                system("COLOR f5");
                printf("%c", 219);
            }
            else
                printf(" ");
        }
    }
}

void bingkai_all(int a, int b, int x, int y){
    for(int i = 1; i <= a; i++){
        koordinat(x, y + i);
        for(int j = 1; j<= b; j++){
            if(j == 1 || j == b){
                printf("%c", 219);
            }else if(i == 1 ){
                printf("%c",223);
            }
            else if(i == a){
                printf("%c",220);
            }
            else{
                printf(" ");
            }
        }
    }
}

void bingkai1()
{
    int a = 67, b = 15;
    char s = 219;
    for (int x = 0; x < b; x++)
    {
        koordinat(0, 0 + x);
        for (int j = 0; j < a; j++)
        {

            if (x == 0 || x == b - 1 || j == 0 || j == a - 1)
            {
                system("COLOR f5");
                printf("%c", 219);
            }
            else
                printf(" ");
        }
    }
}

void frame(int c)
{
    if (c == 0)
    {
        tampilan1();

    }
    else if (c == 1)
    {
        tampilan2();
    }
    else if (c == 2)
    {
        tampilan3();
    }
    else if (c == 3)
    {
        tampilan4();
    }
}

void frame_pilihan(int x, int y){
    int a=30,b=9;
    char s=219;
            for(int i=0; i<b; i++){
                koordinat(x,y+i); 
                for(int j=0; j < a; j++){
                if(i==0||i==b-1||j==0||j==a-1 || j == a - 2 || j == 1){
                    printf("%c",219);
                }else{
                printf(" ");
                }
                }
            }
}

void pilih()
{
    int c = 0;
    char inp;
    // int inp;
    // while ((inp = getch()) != 13)
    while (1){
        inp = getch();
        if(inp == 13){
           
           break;
        }else{
        if (inp == 75)
        {
            c++;
            if (c > 3){
                c = 3;
            }
        }
        else if (inp == 77)
        {
            c--;
            if (c < 0){
                c = 0;
            }
        }
        system("cls");
        frame(c);
        }
    }
    
    if(c == 1){
        login1();
    }else if(c == 2){
        // admin();
    }
    else if(c == 3){
        daftar();
    }
}



void tampilan_pilih(){
    // system("COLOR 72");
    // system("pause");
    // system("COLOR 75");
    // pesawat(10, 11);
    // Sleep(100);
    // system("cls");
    // bingkai();
    frame(0);
    pilih();
    daftar1();
    // admin();
    // login1();
    login_admin();
    
    // login1();
}


// void main()
// {
//     system("COLOR 72");
//     system("pause");
//     system("COLOR 75");
//     pesawat(10, 11);
//     Sleep(100);
//     system("cls");
//     bingkai();
//     frame(0);
//     pilih();
//     system("COLOR 5f");
//     reset();
//     system("cls");
    // tampilan1();
    // Sleep(3000);
    // tampilan2();
    // Sleep(3000);
    // tampilan3();
    // Sleep(3000);
    // tampilan4();
    // sportify();d
    // logo_daftar();
    // logo_admin();
    // logo_login();
    // logo_keluar();
    // menu();
    // daftar();
// }
