#include <stdio.h>
#include <conio.h>

void main()
{
    char nama[100], inp;
    int idx = 0;

    printf("Input nama (minimal 5 Huruf): ");

    while (!0)
    {
        // inputan getch berfungsi untuk mengisi ketikan tapi tidak tampil langsung ke cmd
        inp = getch();

        // jika inputan memenuhi kondisi (inputan harus dibawah 20) diprint %c dulu
        if ((inp >= 'A' && inp <= 'Z') && idx == 0 && idx < 20 || (inp >= 'a' && inp <= 'z') && idx != 0 && idx < 20 ||
            (inp == ' ' && idx > 0 && nama[idx - 1] != ' ' && idx < 20))
        {
            printf("%c", inp);
            nama[idx++] = inp;
        }

        // jika salah di hapus menggunakan \b
        else if (inp == 8 && idx > 0)
        {
            printf("\b \b");
            nama[--idx] = '\0';
        }

        // \r disini dimaksudkan untuk jika menekan enter
        else if (inp == '\r')
        {
            // jika inputan lebih dari 5, enter berfungsi dan keluar dari perulangan menggunakan break
            if (idx >= 5)
            {
                nama[idx] = '\0';
                idx = 0;
                break;

            }
                /* jika inputan alias indeksnya kurang dari 5 tidak, codingan berbunyi
                dan mengulang untuk mengharuskan input kembali*/
            else
            {
                printf("\a");
            }
        }
    }
    /*while disini dimaksudkan untuk inputan 1 1 karakter dan jika kondisi terpenuhi
    akan mengulang kembali setelah diprint %c atau dihapus dengan \b*/
    printf("\nMantap Ya Berhasil");
}