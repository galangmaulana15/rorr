#include <stdio.h>
#include <windows.h>


char* valid_email(char inp[]){
    int g, gmail, y, yahoo, n = 0, val, vall, key, valt;
    char temp;

    printf("Minimal 5 huruf atau angka sebelum @\nInput : "); 
    while((temp = getch())){
        g = strlen(inp);
        y = strlen(inp);
        yahoo = y - 10;
        gmail = g - 10;

        for(int i = 0; i < n; i++){
            if(inp[i] == '@'){
                val = 1;
                key = 1;
            }else if(inp[i] == '.')
                valt = 1;
            if(key == 1){
                vall = 1;
            }
        }
        
        if(n < 19 && (temp >= 'a' && temp <= 'z' || temp >= '0' && temp <= '9' && n > 1) && 
        (temp != inp[n-1] || temp != inp[n-2] || temp != inp[n-3]) ||
        n >= 5 && (temp == '@' && val == 0 || temp == '.' && vall == 1 && valt == 0))
        {
            printf("%c", temp);
            inp[n] = temp;
            n++;
        }
        else if(temp == 8 && n != 0){
            printf("\b \b");
            n--;
            inp[n] = '\0';
        }else if(temp == 13 && n > 14){
            if(strcmp(inp + gmail, "@gmail.com") == 0){
                printf("\n");
                inp[n] = '\0';
                break;
            }else if(strcmp(inp + yahoo, "@yahoo.com") == 0){
                printf("\n");
                inp[n] = '\0';
                break;
            }
        }
        inp[n] = '\0';
        val = 0; vall = 0; key = 0; valt = 0;
    }
    return strcat(inp,"\n");

}
char* valid_pass(char inp[]){
    char temp;
    int n = 0, up = 0, low = 0, num = 0;

    printf("(Minimal 3 huruf kecil, 2 huruf kapital, 3 angka)\nInput : ");
    while(temp = getch()){
        if((temp >= 'A' && temp <= 'Z' || temp >= 'a' && temp <= 'z' || temp >= '0' && temp <= '9') && n < 15){
            printf("$");
            inp[n] = temp;
            n++;
            if(temp >= 'A' && temp <= 'Z'){
                ++up;
            }else if(temp >= 'a' && temp <= 'z'){
                ++low;
            }else{
                ++num;
            }
        }else if(temp == 8 && n > 0){
            if(inp[n-1] >= 'A' && inp[n-1] <= 'Z'){
                --up;
            }else if(inp[n-1] >= 'a' && inp[n-1] <= 'z'){
                --low;
            }else{
                --num;
            }
            printf("\b \b");
            inp[n] = '\0';
            n--;
        }else if(temp == 13 && n > 7 && low >= 3 && up >= 2 && num >= 3){
            printf("\n");
            inp[n] = '\0';
            break;
        }
    }
    return strcat(inp,"\n");
}
void main(){
    char email[100];
    char pass [100];
    valid_email(email);
    valid_pass(pass);
}