#include <stdio.h>

void crud()
{
system("cls");
    int id;
    int i = 0;
    char user[100], pw[100], ubah;
    char email[20], namalengkap[50], username[20],password[10], nomor[10];

    while (i < 3)
    {
        system("cls");
        frame_pilihan(157,36);
        frame_pilihan3(53,15);
        tampilan2();
        // if (pilih == 27) // ascii esc(27), ascii enter(13)
        // {
        //     menu();
        // }
        
        koordinat(70,23);printf("Masukkan username: ");
        koordinat(70,25);printf("Masukkan password: ");
        koordinat(70,24);vusername(user);
        koordinat(70,26);vpass(pw);
        

        FILE *data = fopen("data.txt", "r");
        if (data == NULL)
        {
            koordinat(70,27);printf("Error opening file!");
            return;
        }

        while (fscanf(data, "%d/%[^/]/%[^/]/%[^/]/%[^\n]", &namalengkap,nomor,username,email,password) != EOF)
        {
            if (strcmp(user, username) == 0 && strcmp(password, pw) == 0)
            {
                // upd = id;
                koordinat(70,27);printf("Login berhasil");
                getchar();   
                system("cls");
                // admin();
                fclose(data);
                return;
            }
        }
                fclose(data);

        if (strcmp(user, id) == 0 && strcmp(pw, password) == 0)
        {
            // admin();
            getchar();
            break;
        }
        if (i == 2)
        {
            koordinat(70,27);printf("akun anda terkunci sementara.");
            return;
        }
        else
        {
            koordinat(70,27);printf("Login gagal, harap coba lagi.");
            getchar();
        }
        i++;
    }
}